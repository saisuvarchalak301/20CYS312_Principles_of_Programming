listLength :: [a] -> Int
listLength [] = 0  -- Base case: empty list has length 0
listLength (_:xs) = 1 + listLength xs  -- Recursive case: increment count and recurse on the tail


main :: IO ()
main = do
    let lst = [1, 2, 3, 4, 5]
        lengthOfList = listLength lst
    putStrLn $ "Length of list: " ++ show lengthOfList
