reverseList :: [a] -> [a]
reverseList [] = []  -- Base case: empty list, return empty list
reverseList (x:xs) = reverseList xs ++ [x]  -- Recursive case: reverse the tail and append the head


main :: IO ()
main = do
    let lst = [1, 2, 3, 4, 5]
        reversed = reverseList lst
    putStrLn $ "Reversed list: " ++ show reversed
