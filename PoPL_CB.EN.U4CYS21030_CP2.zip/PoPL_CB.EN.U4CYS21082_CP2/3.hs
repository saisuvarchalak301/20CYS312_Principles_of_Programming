lastElement :: [a] -> a
lastElement [x] = x  -- Base case: list with only one element
lastElement (_:xs) = lastElement xs  -- Recursive case: discard first element and recurse

main :: IO ()
main = do
    let lst = [1, 2, 3, 4, 5]
        result = lastElement lst
    putStrLn $ "Last element: " ++ show result
