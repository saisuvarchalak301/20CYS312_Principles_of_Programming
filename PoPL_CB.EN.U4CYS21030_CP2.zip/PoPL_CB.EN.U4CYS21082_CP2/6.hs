func :: [[a]] -> [[a]]
func [] = []
func ([]:_) = []
func m = [[r !! i | r <- m] | i <- [0..length (head m) - 1]]

main :: IO ()
main = do
    let matrix = [[1, 2, 3],
                  [4, 5, 6],
                  [7, 8, 9]]
    let transposedMatrix = func matrix
    putStrLn "Original matrix:"
    print matrix
    putStrLn "Transposed matrix:"
    print transposedMatrix
