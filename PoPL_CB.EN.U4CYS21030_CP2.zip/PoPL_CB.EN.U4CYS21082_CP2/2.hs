
flatten :: [[a]] -> [a]
flatten xs = [x | sublist <- xs, x <- sublist]


main :: IO ()
main = do
    let result = flatten [[1,2,3],[4,5],[6]]
    putStrLn $ "Result: " ++ show result
