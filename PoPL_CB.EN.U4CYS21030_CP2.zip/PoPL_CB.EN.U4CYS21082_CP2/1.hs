compose :: (b -> c) -> (a -> b) -> a -> c
compose f g x = f (g x)

double :: Int -> Int
double x = x * 2

increment :: Int -> Int
increment x = x + 1

func :: [[a]] -> [[a]]
func [] = []
func ([]:_) = []
func m = [[r !! i | r <- m] | i <- [0..length (head m) - 1]]

main :: IO ()
main = do
    let result = compose double increment 3
    putStrLn $ "Result: " ++ show result
